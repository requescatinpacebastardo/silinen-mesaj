package com.example.silinenmesaj

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Msg(val id: Long, val sender: String, val text: String, val time: Long, val deleted: Boolean)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "msgs.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, text TEXT, time INTEGER, deleted INTEGER DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun add(sender: String, text: String, time: Long) {
        // Aynı mesajın tekrar bildirimini ekleme
        writableDatabase.rawQuery(
            "SELECT 1 FROM msgs WHERE sender=? AND text=? AND ABS(time-?)<5000",
            arrayOf(sender, text, time.toString())
        ).use { if (it.moveToFirst()) return }
        val v = ContentValues().apply { put("sender", sender); put("text", text); put("time", time) }
        writableDatabase.insert("msgs", null, v)
    }

    // Gönderenin en son silinmemiş mesajını "silindi" işaretle
    fun markDeleted(sender: String) {
        writableDatabase.execSQL(
            "UPDATE msgs SET deleted=1 WHERE id=(SELECT id FROM msgs WHERE sender=? AND deleted=0 ORDER BY time DESC LIMIT 1)",
            arrayOf(sender)
        )
    }

    fun all(onlyDeleted: Boolean): List<Msg> {
        val q = "SELECT id,sender,text,time,deleted FROM msgs" +
            (if (onlyDeleted) " WHERE deleted=1" else "") + " ORDER BY time DESC LIMIT 500"
        val out = mutableListOf<Msg>()
        readableDatabase.rawQuery(q, null).use {
            while (it.moveToNext())
                out += Msg(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getInt(4) == 1)
        }
        return out
    }

    fun clear() { writableDatabase.execSQL("DELETE FROM msgs") }
}
