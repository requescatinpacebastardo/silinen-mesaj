package com.example.silinenmesaj

import android.content.Context
import android.os.Environment
import android.os.FileObserver
import java.io.File

/** WhatsApp medya klasörlerini izler, yeni gelen dosyaları kendi klasörüne kopyalar. */
object MediaWatcher {
    private val observers = mutableListOf<Dir>()
    private lateinit var dest: File
    private val skip = setOf("Sent", "Private", ".Statuses", ".Links", ".Thumbs")
    private val roots = listOf(
        "Android/media/com.whatsapp/WhatsApp/Media",
        "WhatsApp/Media",
        "Android/media/com.whatsapp.w4b/WhatsApp Business/Media",
        "WhatsApp Business/Media"
    )

    fun backupDir(ctx: Context) = File(ctx.getExternalFilesDir(null), "yedek").apply { mkdirs() }

    @Synchronized
    fun start(ctx: Context) {
        stop()
        dest = backupDir(ctx)
        val base = Environment.getExternalStorageDirectory()
        roots.map { File(base, it) }.filter { it.isDirectory }.forEach { watch(it, "") }
    }

    @Synchronized
    fun stop() {
        observers.forEach { it.stopWatching() }
        observers.clear()
    }

    @Synchronized
    private fun watch(dir: File, cat: String) {
        if (dir.name in skip) return
        dir.listFiles()?.filter { it.isDirectory }?.forEach {
            watch(it, if (cat.isEmpty()) it.name else cat)
        }
        val o = Dir(dir.path, cat)
        o.startWatching()
        observers += o
    }

    private fun copy(src: File, cat: String) {
        try {
            val d = File(dest, cat.ifEmpty { "Diger" }).apply { mkdirs() }
            val t = File(d, src.name)
            if (!t.exists()) src.copyTo(t)
        } catch (_: Exception) { }
    }

    private class Dir(val path: String, val cat: String) :
        FileObserver(path, CLOSE_WRITE or MOVED_TO or CREATE) {
        override fun onEvent(event: Int, name: String?) {
            name ?: return
            val f = File(path, name)
            if (f.isDirectory) {
                if (event and CREATE != 0) watch(f, if (cat.isEmpty()) name else cat)
                return
            }
            if (event and (CLOSE_WRITE or MOVED_TO) == 0) return
            if (name.startsWith(".") || name.endsWith(".tmp")) return
            copy(f, cat)
        }
    }
}
