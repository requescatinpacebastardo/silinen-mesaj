package com.example.silinenmesaj

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class Listener : NotificationListenerService() {

    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b")

    // WhatsApp'ın silinen mesaj için bıraktığı metinler
    private val deletedTexts = listOf(
        "bu mesaj silindi", "this message was deleted", "bu mesajı sildin", "you deleted this message"
    )

    override fun onListenerConnected() {
        MediaWatcher.start(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in packages) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return

        // "3 yeni mesaj" gibi özet bildirimleri atla
        if (Regex("^\\d+ (yeni )?(mesaj|messages?)").containsMatchIn(text.lowercase())) return
        if (sender.equals("WhatsApp", true)) return

        val db = Db(applicationContext)
        if (deletedTexts.any { text.lowercase().contains(it) }) {
            db.markDeleted(sender)
        } else {
            db.add(sender, text, sbn.postTime)
        }
    }
}
