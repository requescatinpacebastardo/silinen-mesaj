package com.example.silinenmesaj

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var mode = 0 // 0 silinenler, 1 tümü, 2 medya
    private val fmt = SimpleDateFormat("dd.MM HH:mm", Locale("tr"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 16) }
        status = TextView(this).apply { textSize = 14f }

        fun row(vararg btns: Pair<String, () -> Unit>) = LinearLayout(this).apply {
            btns.forEach { (t, a) ->
                addView(Button(context).apply { text = t; textSize = 12f; setOnClickListener { a() } },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        }

        root.addView(status)
        root.addView(row(
            "Bildirim izni" to { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            "Dosya izni" to { askFileAccess() }
        ))
        root.addView(row(
            "Silinenler" to { mode = 0; refresh() },
            "Tümü" to { mode = 1; refresh() },
            "Medya" to { mode = 2; refresh() }
        ))
        root.addView(row("Mesajları temizle" to { db.clear(); refresh() }))

        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (hasFileAccess()) MediaWatcher.start(applicationContext)
        refresh()
    }

    private fun hasNotifAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(ComponentName(this, Listener::class.java).flattenToString())
    }

    private fun hasFileAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == 0

    private fun askFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (hasFileAccess()) MediaWatcher.start(applicationContext)
        refresh()
    }

    private fun refresh() {
        status.text = (if (hasNotifAccess()) "✅ Mesaj dinleme aktif\n" else "⚠️ Bildirim izni kapalı\n") +
            (if (hasFileAccess()) "✅ Medya yedekleme aktif" else "⚠️ Dosya izni kapalı (medya yedeklenmez)")
        if (mode == 2) showMedia() else showMessages()
    }

    private fun showMessages() {
        val msgs = db.all(mode == 0)
        list.setOnItemClickListener(null)
        list.adapter = object : ArrayAdapter<Msg>(this, 0, msgs) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val m = getItem(i)!!
                val tv = (v as? TextView) ?: TextView(context).apply { setPadding(8, 20, 8, 20); textSize = 15f }
                tv.text = (if (m.deleted) "🗑 " else "") + m.sender + "  ·  " + fmt.format(Date(m.time)) + "\n" + m.text
                tv.setTextColor(if (m.deleted) Color.RED else Color.BLACK)
                return tv
            }
        }
    }

    private fun showMedia() {
        val base = MediaWatcher.backupDir(this)
        val files = base.walkTopDown().filter { it.isFile }.sortedByDescending { it.lastModified() }.take(500).toList()
        list.adapter = object : ArrayAdapter<File>(this, 0, files) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val f = getItem(i)!!
                val tv = (v as? TextView) ?: TextView(context).apply { setPadding(8, 20, 8, 20); textSize = 14f }
                tv.text = "📎 " + f.parentFile?.name + "\n" + f.name + "  ·  " +
                    (f.length() / 1024) + " KB  ·  " + fmt.format(Date(f.lastModified()))
                return tv
            }
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val f = files[pos]
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (e: Exception) {
                Toast.makeText(this, "Bu dosyayı açacak uygulama yok", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
